import React, { useState, useRef } from "react";
import { View, Text, TextInput, Button, StyleSheet } from "react-native";

const App = () => {
  const inputRef = useRef(null);
  const resultRef = useRef(null);
  const [result, setResult] = useState(0);

  const plus = () => {
    setResult((prevResult) => prevResult + parseFloat(inputRef.current.value));
  };

  const minus = () => {
    setResult((prevResult) => prevResult - parseFloat(inputRef.current.value));
  };

  const times = () => {
    setResult((prevResult) => prevResult * parseFloat(inputRef.current.value));
  };

  const divide = () => {
    setResult((prevResult) => prevResult / parseFloat(inputRef.current.value));
  };

  const resetInput = () => {
    inputRef.current.clear();
  };

  const resetResult = () => {
    setResult(0);
    inputRef.current.clear();
  };

  return (
    <View style={styles.container}>
      <View>
        <Text style={styles.heading}>Simplest Working Calculator</Text>
      </View>
      <View>
        <Text ref={resultRef}>{result}</Text>
        <TextInput
          ref={inputRef}
          keyboardType="numeric"
          placeholder="Type a number"
          style={styles.input}
        />
        <Button title="Add" onPress={plus} />
        <Button title="Subtract" onPress={minus} />
        <Button title="Multiply" onPress={times} />
        <Button title="Divide" onPress={divide} />
        <Button title="Reset Input" onPress={resetInput} />
        <Button title="Reset Result" onPress={resetResult} />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#fff",
  },
  heading: {
    fontSize: 24,
    fontWeight: "bold",
    marginBottom: 20,
  },
  input: {
    width: 200,
    height: 40,
    borderColor: "gray",
    borderWidth: 1,
    marginBottom: 10,
    paddingHorizontal: 10,
  },
});

export default App;
